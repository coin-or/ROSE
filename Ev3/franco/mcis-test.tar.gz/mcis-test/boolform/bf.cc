/**********************************************************************
* Author:      Franco Raimondi                                        *
* Name:        bf.h                                                   *
* Source:      GNU C++                                                *
* Purpose:     Boolean expressions (base classes and functionality)   *
* History:     040609 work started                                    *
***********************************************************************/


using namespace std;

#include <string>
#if __GNUC__ == 3
#include <sstream>
#else
#include <strstream>
#endif
#include <cmath>
#include <algorithm>
#include <cassert>
#include "../zchaff/SAT.h"
#include "bf.h"


#define PEV3PI 3.1415926535897932385
#define NOTVARNAME "_var_not_found_"


///////////// classes ////////////////

// constructors
Operand::Operand() : 
  oplabel(BFCONST), constant(0), varindex(NOVARIABLE) { }


Operand::Operand(bool t) : 
  oplabel(BFCONST), constant(t), varindex(NOVARIABLE) { }


// create a variable leaf
Operand::Operand(const int t, string vn)
{ 
  // make it a variable
  oplabel = BFVAR;
  constant = 0;
  varindex = t;
  varname = vn;
}

// copy constructor
Operand::Operand(const Operand& t) : 
  oplabel(t.oplabel), constant(t.constant), 
  varindex(t.varindex), varname(t.varname) { }

// destructor
Operand::~Operand() { }

// Operand class methods:

string Operand::ToString(void) const {
#if __GNUC__ == 3
  stringstream outbuf;  
#else
  strstream outbuf;
#endif
  string vn;
  if (GetOpType() == BFCONST) {
    // constant
    outbuf << GetValue();
  } else if (GetOpType() == BFVAR) {
    // variable
    vn = GetVarName();
    outbuf << vn;
  } else {
    // operand, don't print anything
    ;
  }
  return outbuf.str();
}

// get operator type
int Operand::GetOpType(void) const { return oplabel; }
  
// get constant value - in BFCONSTs, multiply by coeff. and raise 
// to exponent, first
bool Operand::GetValue(void) const { 
  if (oplabel == BFCONST) {
    return constant;
  } else {
    return constant; 
  }
}

// get variable index
Int Operand::GetVarIndex(void) const { return varindex; }

// get variable name
string Operand::GetVarName(void) const { return varname; }

// set operator type
void Operand::SetOpType(const int t) { oplabel = t; }
  
// set constant value
void Operand::SetValue(const bool t) { oplabel = BFCONST; constant = t; }

// set variable index
void Operand::SetVarIndex(const Int t) { oplabel = BFVAR; varindex = t; }

// set variable name
void Operand::SetVarName(const string vn) { oplabel = BFVAR; varname = vn; }

// is operand a constant?
bool Operand::IsConstant(void) const {
  return (GetOpType() == BFCONST);
}

// is operand a variable?
bool Operand::IsVariable(void) const {
  return (GetOpType() == BFVAR);
}

// is operand a leaf node?
bool Operand::IsLeaf(void) const {
  return (IsConstant() || IsVariable());
}

// is operand a zero constant?
bool Operand::IsZero(void) const {
  if (GetOpType() == BFCONST) {
    bool c = GetValue();
    if (c) {
      return true;
    } else {
      return false;
    }
  } else {
    return false;
  }
}
  

// is operand this == operand t?
bool Operand::operator == (const Operand& t) {
  if (this == &t) {
    // first fast check
    return true;
  } else {
    // not the same operand - check data fields
    return (GetOpType() == t.GetOpType() &&
	    GetValue() == t.GetValue() &&
	    GetVarIndex() == t.GetVarIndex());
  }
}      

// substitute a variable with a constant
void Operand::SubstituteVariableWithConstant(long int varindex, bool c) {
  if (GetOpType() == BFVAR && GetVarIndex() == varindex) {  
    SetOpType(BFCONST);
    SetVarIndex(NOVARIABLE);
    SetValue(c);    
  }
}


// create empty
BasicBoolForm::BasicBoolForm() { }

// create a constant leaf
BasicBoolForm::BasicBoolForm(const bool t) : Operand(t) { }

// create a variable leaf
BasicBoolForm::BasicBoolForm(const int t, const string vn) : 
  Operand(t, vn) { }
  
// user-defined copy constructor with two options
BasicBoolForm::BasicBoolForm(const BoolForm& t, const bool iscopy) :
  Operand(t.GetPointee()) {
  int i = 0;
  int s = t->GetSize();
  if (iscopy) {
    // create a _copy_ of t, subnode by subnode
    for ( ; i < s; i++)
      nodes.push_back(t->GetCopyOfNode(i));
  } else {
    // create a copy of the pointers in t
    for ( ; i < s; i++)
      nodes.push_back(t->GetNode(i));
  }
}

// copy constructor
BasicBoolForm::BasicBoolForm(const BasicBoolForm& t) : Operand(t) { 
  Int i = 0;
  Int s = t.GetSize();
  // necessary for constructs "(BasicBoolForm) e =" where e already 
  // existed prior to assignment  
  DeleteAllNodes(); 
  // create a copy of the subnode pointers in t
  for ( ; i < s; i++)
    nodes.push_back(t.GetNode(i));
}

// destructor
BasicBoolForm::~BasicBoolForm() { }

// BasicBoolForm class methods:

void BasicBoolForm::Debug (void) const {
  Int s = GetSize();
  cerr << "BasicBoolForm: Debug:\n";
  cerr << "\tthis   = " << this << endl;
  cerr << "\toptype = " << GetOpType() << endl;
  cerr << "\tnodes  = " << s << endl;
  Int i;
  for (i = 0; i < s; i++) {
    cerr << "\tnode " << i << ": " << GetNode(i)->GetOpType() << endl;
  }
}  

void BasicBoolForm::Zero(void) {
  DeleteAllNodes();
  SetValue(0);
  SetOpType(BFCONST);
}

void BasicBoolForm::One(void) {
  DeleteAllNodes();
  SetValue(1);
  SetOpType(BFCONST);
}

string BasicBoolForm::PrintTree(int blanks, int tabs) const {
#if __GNUC__ == 3
  stringstream outbuf;
#else
  strstream outbuf;
#endif 
  string b(blanks, ' ');
  if (IsLeaf()) {
    outbuf << b << Operand::ToString();
  } else {
    outbuf << b << "OP[" << GetOpType() << "](" << endl;
    for(int i = 0; i < GetSize(); i++) {
      outbuf << GetNode(i)->PrintTree(blanks + tabs, tabs);
      if (i < GetSize() - 1) {
        outbuf << ",";
      }
      outbuf << endl;
    }
    outbuf << b << ")";
  }
  return outbuf.str();
}

string BasicBoolForm::ToString(void) const {
#if __GNUC__ == 3
  stringstream outbuf;
#else
  strstream outbuf;
#endif  
  Int i, s;
  if (IsLeaf()) {
    // leaf node, use Operand::ToString()
    return Operand::ToString();
  } else {
    s = GetSize();
    if (s > 1) {
      string t;
      for (i = 0; i < s; i++) {
	t = GetNode(i)->ToString();
	outbuf << "(" << t << ")";
	if (i < s - 1) {
	  switch(GetOpType()) {
	  case BFAND:
	    outbuf << "*";
	    break;
	  case BFOR:
	    outbuf << "+";
	    break;
	  default:
	    outbuf << "UNKNOWNOP";
	    break;
	  }
	}
      }    
    } else {
      switch(GetOpType()) {
      case BFNOT:
	outbuf << "!";
	break;
      default:
	outbuf << "UNKNOWNOP";
      }
      if (s == 1) {
	string t(GetNode(0)->ToString());
	outbuf << "(" << t << ")";
      } else {
	// no arguments - error
	outbuf << "(NOARG)";
      }
    }
    return outbuf.str();
  }
}


void BasicBoolForm::PrintCNF(void) {
  Int s;
  if (IsLeaf()) {
    if ( GetOpType() == BFVAR ) {
      cout << GetVarIndex();
    } else if ( GetOpType() == BFCONST && GetValue() == true ) {
      cout << "-1 1";
    }
  } else {
    s = GetSize();
    if (s > 1) {
      GetNode(0)->PrintCNF();
      switch(GetOpType()) {
      case BFAND:
	cout << endl;
	break;
      case BFOR:
	cout << " ";
	break;
      default:
	cout << "UNKNOWNOP";
	break;
      }
      GetNode(1)->PrintCNF();
    } else {
      switch(GetOpType()) {
      case BFNOT:
	cout << "-";
	break;
      default:
	cout << "UNKNOWNOP";
      }
      if (s == 1) {
	GetNode(0)->PrintCNF();
      } else {
	// no arguments - error
	cout << "(NOARG)";
      }
    }
  }
}

void addClause(BoolForm a, Clause *cla, ClauseSet *cs) 
{
  int s;
  
  s = a->GetSize();
  if (s > 1) {
    switch(a->GetOpType()) {
    case BFAND:
      addClause(a->GetNode(0),cla, cs);
      cs->push_back(Clause(*cla));
      cla->clear();
      addClause(a->GetNode(1),cla,cs);
      cs->push_back(Clause(*cla));
      cla->clear();
      break;
    case BFOR:
      addClause(a->GetNode(0),cla,cs);
      addClause(a->GetNode(1),cla,cs);
      break;
    default:
      cout << "UNKNOWNOP";
      break;
    }
  } else {
    switch(a->GetOpType()) {
    case BFNOT:
      {
	BoolForm f1 = a->GetNode(0);
	if ( f1->GetOpType() == BFVAR ) {
	  cla->push_back(- f1->GetVarIndex());
	} else if ( f1->GetOpType() == BFCONST && f1->GetValue() == false ) {
	  cla->push_back(0); // Will be removed later
	}
	break;
      }
    case BFVAR:
      {
	cla->push_back(a->GetVarIndex());
	break;
      }
    case BFCONST:
      {
	if ( a->GetValue() == true ) {
	  cla->push_back(0); // Will be removed later
	}
	break;
      }
    default:
      cout << "UNKNOWNOP";
      break;
    }
  }
}


bool hasSizeZero(Clause *cla) 
{
  return (!( cla->size() > 0 ));
}


ClauseSet BasicBoolForm::CNFToCS(void) {
  
  BoolForm ret = *this;
  ClauseSet *cs;
  cs = new ClauseSet();
  Clause *cla = new Clause();

  addClause(ret, cla, cs);

  

  ClauseSet::iterator csi;
  Clause::iterator ci;
  // Some cleanup. Remove duplicate variables from clauses

  for ( csi = cs->begin(); csi != cs->end(); csi++ ) {
    stable_sort(csi->begin(), csi->end());
    csi->erase(unique(csi->begin(), csi->end()),csi->end());
  }

  // remove empty clauses,
  // remove clauses with a 0 (i.e. with true, see CNFToCS

  csi = cs->begin();
  while ( csi != cs->end() ) {
    if ( !( csi->size() > 0 ) ) {
      csi = cs->erase(csi);
    } else if ( find(csi->begin(),csi->end(), 0 ) != csi->end() ) {
      csi = cs->erase(csi);
    }
    else {
      ++csi;
    }
    
  }


  // Remove clauses with a var and its negation
  csi = cs->begin();
  while ( csi != cs->end() ) {
    int erase = 0;
    for ( ci = csi->begin(); ci != csi->end(); ci++ ) {
      if ( *ci < 0 ) {
	if ( find(csi->begin(),csi->end(), abs(*ci) ) != csi->end() ) {
	  erase = 1;
	}
      }
    }
    if ( erase == 1 ) {
      csi = cs->erase(csi);
    }
    else {
      ++csi;
    }
    
  }
  
  return (*cs);
}




void BasicBoolForm::VariableToConstant(long int varindex, bool c) {
  if (IsLeaf()) {
    // nonrecursive
    SubstituteVariableWithConstant(varindex, c);
  } else {
    // recursive
    int i;
    for (i = 0; i < GetSize(); i++) {
      GetNode(i)->VariableToConstant(varindex, c);
    }
  }
}



// OR operator:
BoolForm operator + (BoolForm a, BoolForm b) {
  BoolForm ret;

  if (a->IsLeaf() && a->GetOpType() == BFCONST &&
      b->IsLeaf() && b->GetOpType() == BFCONST) {
    // a, b are constants
    ret.SetToCopyOf(a);
    ret->SetValue(a->GetValue() || b->GetValue());
    return ret;
  } else {
    ret->SetOpType(BFOR);
    ret->AddCopyOfNode(a);
    ret->AddCopyOfNode(b);
    return ret;
  }
}

// AND operator:
BoolForm operator * (BoolForm a, BoolForm b) {
  BoolForm ret;

  if (a->IsLeaf() && a->GetOpType() == BFCONST &&
      b->IsLeaf() && b->GetOpType() == BFCONST) {
    // a, b are constants
    ret.SetToCopyOf(a);
    ret->SetValue(a->GetValue() && b->GetValue());
    return ret;
  } else {
    ret->SetOpType(BFAND);
    ret->AddCopyOfNode(a);
    ret->AddCopyOfNode(b);
    return ret;
  }
}

// NOT operator
BoolForm operator ! (BoolForm a) {
  BoolForm ret;
    
  if (a->IsLeaf() && a->GetOpType() == BFCONST) {
    ret->SetValue(!(a->GetValue()));
  } else {
    ret->SetOpType(BFNOT);
    ret->AddCopyOfNode(a);
    
  }
  return ret;
}

// Push negations to atoms, using de Morgan
BoolForm PushNeg ( BoolForm a ) 
{
  BoolForm ret;
  int s;
  if ( a->IsLeaf() ) {
    ret.SetToCopyOf(a);
    return ret;
  } else {
    s = a->GetSize();
    if (s > 1) {
      BoolForm f1, f2;
      f1 = a->GetNode(0);
      f2 = a->GetNode(1);
      switch( a->GetOpType() ) {
      case BFAND:
	ret = PushNeg(f1) * PushNeg(f2);
	break;
      case BFOR:
	ret = PushNeg(f1) + PushNeg(f2);
	break;
      default:
	break;
      }
    } else {
      if (a->GetOpType() == BFNOT ) {
	// Difficult bit.
	BoolForm f1;
	f1 = a->GetNode(0);
	if ( f1->IsLeaf() ) {
	  ret.SetToCopyOf(a);
	  return ret;
	}
	else {
	  switch( f1->GetOpType() ) {
	  case BFAND:
	    { BoolForm f2,f3;
	    f2 = f1->GetNode(0);
	    f3 = f1->GetNode(1);	    
	    ret = PushNeg(!f2) + PushNeg(!f3);
	    return ret;
	    break;
	    }
	    
	  case BFOR:
	    { BoolForm f2,f3;
	    f2 = f1->GetNode(0);
	    f3 = f1->GetNode(1);
	    ret = PushNeg(!f2) * PushNeg(!f3);
	    return ret;
	    break; 
	    }
	  case BFNOT:
	    { BoolForm f2;
	    f2 = f1->GetNode(0);
	    ret = PushNeg(f2);
	    return ret;
	    break;
	    }
	    
	  default:
	    break;
	  }
	}
      }
    }
  }
  return ret;
}

BoolForm BasicBoolForm::Exists(int varindex) 
{
  BoolForm a,b,ret;
  a.SetToCopyOf(*this);
  b.SetToCopyOf(*this);
  a->VariableToConstant(varindex,true);
  b->VariableToConstant(varindex,false);
  ret = a + b;
  return ret;
}

  
BoolForm BasicBoolForm::Exists(vector<int> vars) 
{
  BoolForm ret;
  ret.SetToCopyOf(*this);
  vector<int>::iterator vi;
  if (!vars.empty()) {
    for ( vi = vars.begin(); vi != vars.end(); vi++ ) {
      BoolForm a,b;
      a.SetToCopyOf(ret);
      b.SetToCopyOf(ret);
      a->VariableToConstant(*vi,true);
      b->VariableToConstant(*vi,false);
      ret = a + b;
    }
  }
  return ret;
}


BoolForm oneStepToCNF( BoolForm a, bool* pushed ) 
{
  // pushed is used to denote a swap BFOR -> BFAND
  //  a->Debug();
  BoolForm ret;

  int s;
  
  if ( a->IsLeaf() ) {
    ret.SetToCopyOf(a);
    return ret;
  } else {
    // It's not a leaf
    s = a->GetSize();
    if (s > 1) {
      // It's not a negation
      BoolForm f1, f2;
      f1 = a->GetNode(0);
      f2 = a->GetNode(1);
      switch( a->GetOpType() ) {
      case BFAND:
	// Easy one.
	ret = oneStepToCNF(f1,pushed) * oneStepToCNF(f2,pushed);
	return ret;
	break;
      case BFOR:
	// Difficult one: push down the BFOR's into BFAND's
	// Various cases:
	if (f1->GetOpType() == BFAND) {
	  // There's an BFAND below.
	  BoolForm f3, f4;
	  f3 = f1->GetNode(0);
	  f4 = f1->GetNode(1);
	  ret =  oneStepToCNF((f3 + f2),pushed) * oneStepToCNF((f4 + f2),pushed);
	  (*pushed) = 1;
	  return ret;
	}
	else if ( f2->GetOpType() == BFAND ) {
	  // There's an BFAND below.
	  BoolForm f3, f4;
	  f3 = f2->GetNode(0);
	  f4 = f2->GetNode(1);
	  ret =  oneStepToCNF((f3 + f1),pushed) * 
	    oneStepToCNF((f4 + f1),pushed);
	  *pushed = 1;
	  return ret;
	}
	else {
	  ret = oneStepToCNF(f1,pushed) + oneStepToCNF(f2,pushed);
	  return ret;
	}
	break;
      default:
	break;
      }
    } else {
      // CAUTION!!!!
      // Assuming a is already PushNeg!
      ret.SetToCopyOf(a);
      return ret;
    }
  }
  return ret;
}

BoolForm ToCNF( BoolForm a ) 
{
  BoolForm ret = PushNeg(a);
  
  bool pushed = 0;

  ret = oneStepToCNF(ret,&pushed);

  while ( pushed != 0 ) {
    pushed = 0;
    ret = oneStepToCNF(ret,&pushed);
  }
  return ret;
}

int BasicBoolForm::NumberOfVariables() const {
  int maxvi = 0;
  return NumberOfVariables(maxvi);
}

bool BasicBoolForm::IsSAT() const 
{

  BoolForm equiv;

  equiv = *this;
  
  equiv = ToCNF(equiv);

  int nvar = equiv->NumberOfVariables();
  
  ClauseSet cs;
  cs = equiv->CNFToCS();
  ClauseSet::iterator csi;
  Clause::iterator ci;

  SAT_Manager mng = SAT_InitManager();
  
  for ( int i = 1; i <= nvar; i++ ) {
    SAT_AddVariable(mng);
  } 
  
  vector<int> temp;

  for ( csi = cs.begin(); csi != cs.end(); csi++ ) {
    for ( ci = csi->begin(); ci != csi->end(); ci++ ) {
      if ( *ci > 0 ) {
	temp.push_back(2 * (*ci));
      } else {
	temp.push_back(2 * abs(*ci) + 1);
      }
    }
    SAT_AddClause(mng, & temp.begin()[0], temp.size() );
    temp.clear();
  }

  int result = SAT_Solve(mng);
  
  SAT_ReleaseManager(mng);
  
  if (result == SATISFIABLE) {
    // The negation of the equiv is SAT
    return true;
  } else {
    return false;
  }
}

bool BasicBoolForm::operator==(const BasicBoolForm& t) const 
{
  return equivalent(this,t);
}


  

int BasicBoolForm::NumberOfVariables(int& maxvi) const {
  int newvi = 0;
  if (IsVariable()) {
    newvi = GetVarIndex();
    if (newvi > maxvi) {
      maxvi = newvi;
    }
    return maxvi;
  } else if (!IsLeaf()) {
    for(int i = 0; i < GetSize(); i++) {
      newvi = GetNode(i)->NumberOfVariables(maxvi);
      if (newvi > maxvi) {
        maxvi = newvi;
      }
    }
    return maxvi;
  } else {
    return 0;
  }
}




bool equivalent( const BoolForm a, const BoolForm b ) 
{
  // Check equality with SAT

  // build equivalence
  BoolForm equiv = !(( !a + b ) * ( !b + a ));
  
  if ( equiv->IsSAT() ) {
    return false;
  } else {
    return true;
  }
}

bool operator == ( const BoolForm a, const BoolForm b ) 
{
  return ( a->operator==(&b) );
}
