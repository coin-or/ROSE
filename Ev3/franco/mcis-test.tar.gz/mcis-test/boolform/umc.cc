#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <malloc.h>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>
#include "bf.h"

extern "C" {
  int yyparse(void);
#include "../pnode/pnode2.h"
}


#include "umc.hh"


extern float log_2(int x);

extern vector<string> agtnames;
extern vector<string> lstates;
extern vector<string>::iterator igs,si;
extern vector< vector<string> > lstatelist;
extern vector< vector<string> >::iterator lsli;

extern vector<string> actions;
extern vector< vector<string> > actionlist;
extern vector< vector<string> >::iterator ali;

extern map< string, vector<string> > protocol;
extern vector < map< string, vector<string> > > protlist;

extern map< string, pnode_ptr> evcond; /* EVOLUTION FUNCTIONS */
extern vector < map< string, pnode_ptr> > evcondlist;

extern map< string, pnode_ptr> evalcond; /* EVALUATION */

extern vector < pnode_ptr > iscond; /* INITIAL STATES, a single value vector (?) */

extern map < string, vector < string > > groups; /* For group modalities */

extern vector < pnode_ptr > formulaelist; /* Formulae to be checked */

// Utility vars:
extern vector< string > strvect;
extern vector< int > nls; // number of local states per agent
extern vector< int > nact; // number of actions per agent


// Variables for UMC
extern vector < BasicBoolForm* > bv, bpv, ba ;
// Local states, next local states, and actions
extern vector<BoolForm> bfp; // For protocols

BoolForm list2xor(vector< BoolForm > bflist) 
{
  BoolForm result;
  result->Zero();
  
  if (bflist.size() < 1) return result;
  
  BoolForm bfTrue;
  bfTrue->One();
  BoolForm tmpres;
  tmpres->One();
  
  vector< BoolForm>::iterator bfli;
  
  int j = 0;
  
  int i = 0;

  for ( i = 0; i < (int)bflist.size(); i++ ) {
    for( bfli = bflist.begin();  bfli != bflist.end(); bfli++ ) {
      if ( j == i ) {
	tmpres = tmpres * (*bfli);
      }
      else {
	tmpres = tmpres * !(*bfli);
      }
    }
    result = result + tmpres;
    tmpres = bfTrue;
    j++;
  }
  return result;
}

  
BoolForm lsbf(string name, string lst) 
{
  BoolForm result;
  result->One();
  vector< string > agtlst;
  vector<string>::iterator igs;
  int pos = -1; // Agent number
  int i=0;
  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    if ( *igs == name ) {
      pos = i;
    }
    i++;
  }
  if ( pos < 0 ) {
    result->Zero();
    return result;
  }
  agtlst = lstatelist[pos];
  
  int lspos = -1; // local state number
  i = 0;
  for( igs = agtlst.begin(); igs != agtlst.end(); igs++) {
    if ( *igs == lst ) {
      lspos = i;
    }
    i++;
  }
  if ( lspos < 0 ) {
    result->Zero();
    return result;
  }   
    
  int k = 0; // starting variable;
  for ( i = 0; i < pos; i++ ) {
    k += nls[i];
  }
  
  int nvls = nls[pos]; // Number of variables for this set of local states;
  
  for ( i = 0; i < nvls; i++ ) {
    if ( ( lspos & (int) pow((double)2,(double)i) ) == 0 ) {
      //cout << "pos" << endl;
      result = result * (*bv[k+i]);
    }
    else {
      //cout << "neg" << endl;
      result = result * !(*bv[k+i]);
    }
  }
  	// DEBUG
  //	cout << "Agt name: " << name << " lstate: "<< lst <<endl;
  //result.print(2,2);
  return result; 
}

BoolForm lsbfpv(string name, string lst) 
  // For prime variables
{
  BoolForm result;
  result->One();
  vector< string > agtlst;
  vector<string>::iterator igs;
  int pos = -1; // Agent number
  int i=0;
  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    if ( *igs == name ) {
      pos = i;
    }
    i++;
  }
  if ( pos < 0 ) {  
    result->Zero();
    return result;
  }
  agtlst = lstatelist[pos];
  
  int lspos = -1; // local state number
  i = 0;
  for( igs = agtlst.begin(); igs != agtlst.end(); igs++) {
    if ( *igs == lst ) {
      lspos = i;
    }
    i++;
  }
  if ( lspos < 0 ) {
    result->Zero();
    return result;
  }
    
  int k = 0; // starting variable;
  for ( i = 0; i < pos; i++ ) {
    k += nls[i];
  }
  
  int nvls = nls[pos]; // Number of variables for this set of local states;
  
  for ( i = 0; i < nvls; i++ ) {
    if ( ( lspos & (int) pow((double)2,(double)i) ) == 0 ) {
      //cout << "pos" << endl;
      result = result * (*bpv[k+i]);
    }
    else {
      //cout << "neg" << endl;
      result = result * !(*bpv[k+i]);
    }
  }
  	// DEBUG
  //	cout << "Agt name: " << name << " lstate: "<< lst <<endl;
  //result.print(2,2);
  return result; 
}

BoolForm actbf(string name, string act) 
{

  vector<string>::iterator ligs;
  BoolForm result;
  result->One();
  vector< string > agtlst;
  int pos = -1; // Agent number
  int i=0;
  for( ligs = agtnames.begin(); ligs != agtnames.end(); ligs++) {
    if ( *ligs == name ) {
      pos = i;
    }
    i++;
  }
  if ( pos < 0 ) {
    result->Zero();
    return result;
  }
  agtlst = actionlist[pos];
  
  int actpos = -1; // local state number
  i = 0;
  for( ligs = agtlst.begin(); ligs != agtlst.end(); ligs++) {
    if ( *ligs == act ) {
      actpos = i;
    }
    i++;
  }
  if ( actpos < 0 ) {
    result->Zero();
    return result;
  }
  
  int k = 0; // starting variable;
  for ( i = 0; i < pos; i++ ) {
    k += nact[i];
  }
  
  int nvact = nact[pos]; // Number of variables for this set of local states;
  
  for ( i = 0; i < nvact; i++ ) {
    if ( ( actpos & (int) pow((double)2,(double)i) ) == 0 ) {
      //cout << "pos" << endl;
      result = result * (*ba[k+i]);
    }
    else {
      //cout << "neg" << endl;
      result = result * ! (*ba[k+i]);
    }
  }
  
  return result; 
}



BoolForm print_pnode_bf( string agtname, pnode_ptr pnode )
{
  BoolForm result;
  result->Zero();
  string tmpagtname;
  string type;
  string tmpvalue;
  
  if ( pnode->type == LEAF ) {
    // Parse the value
    string tmpstr = pnode->value;
    if ( tmpstr.find( ".", 0 ) != string::npos  ) {
      // There is a dot, check the name and if it is action or state
      tmpagtname=tmpstr.substr(0,tmpstr.find("."));
      type=tmpstr.substr(tmpstr.find(".")+1,
			 tmpstr.find("=")-tmpstr.find(".")-1);
      tmpvalue=tmpstr.substr(tmpstr.find("=")+1,
			     tmpstr.size()-tmpstr.find("=")-1);
      //cout << "Dot found: "<< tmpstr << endl;
      //cout << tmpagtname << " " << type << " " << tmpvalue << endl;
      if ( type == "Lstate" ) {
	result = BoolForm(lsbf(tmpagtname,tmpvalue));
      }
      if ( type == "Action" ) {
	result =  BoolForm(actbf(tmpagtname,tmpvalue));
      }  
    }
    else {
      //cout << "Dot not found: "<< tmpstr << endl;
      type=tmpstr.substr(0,tmpstr.find("="));
      tmpvalue=tmpstr.substr(tmpstr.find("=")+1,
			     tmpstr.size()-tmpstr.find("=")-1);
      //cout << agtname << " " << type << " " << tmpvalue << endl;
      if ( type == "Lstate" ) {
	result = BoolForm(lsbf(agtname,tmpvalue));
      }
      if ( type == "Action" ) {
	result = BoolForm(actbf(agtname,tmpvalue));
      }  
    }
  }
  
  else {
    if ( pnode->type == 1 ) { // AND
      result = print_pnode_bf(agtname,lookup(pnode->left)) * 
	print_pnode_bf(agtname,lookup(pnode->right));
    }
    if ( pnode->type == 2 ) { // OR
      result = print_pnode_bf(agtname,lookup(pnode->left)) +
	print_pnode_bf(agtname,lookup(pnode->right));
    }
    if ( pnode->type == 3 ) { // NOT
      result = !(print_pnode_bf(agtname,lookup(pnode->left)));
    }
  }
  return result;
}




void umcEncode(void) {

  map< string, vector<string> >::iterator pi;
  map< string, pnode_ptr>::iterator eci;

  // Compute number of vars for local states and actions:
  int lsnbddvar = 0; // Total number of bool vars for local states
  int anbddvar = 0; // Total number of bool vars for actions
  int i = 0;
  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    //cout << "Name: " << *igs << endl;
    //cout << "Number of local states: ";
    lstates = lstatelist[i];
    //cout << lstates.size() << "; Number of boolean vars: ";
    nls.push_back((int)ceil(log_2(lstates.size())));
    lsnbddvar += (int) ceil(log_2(lstates.size()));
    // cout << ceil(log_2(lstates.size())) << endl;
    actions = actionlist[i];
    //cout << "Number of actions: " << actions.size() 
    // << "; Number of boolean vars: ";
    nact.push_back((int)ceil(log_2(actions.size())));
    //cout << ceil(log_2(actions.size())) << endl;
    anbddvar+= (int)ceil(log_2(actions.size()));
    i++;
  }
  
  cout << endl << "building boolean variables..." << endl;
  cout << "done: " << lsnbddvar << " for local states, " 
       << anbddvar << " for actions." << endl;

  for ( i = 0; i < lsnbddvar; i++ ) {
    char buf[10];
    sprintf(buf, "%d", i);
    string tmp;
    tmp = buf;
    tmp = "v"+tmp;
    bv.push_back( new BasicBoolForm(i+1, tmp) );
  }

  for ( i = 0; i < lsnbddvar; i++ ) {
    char buf[10];
    sprintf(buf, "%d", lsnbddvar+i+1);
    string tmp;
    tmp = buf;
    tmp = "v"+tmp;
    bpv.push_back( new BasicBoolForm(lsnbddvar+i+1,tmp) );
  }

  for ( i = 0; i < anbddvar; i++ ) {
    char buf[10];
    sprintf(buf, "%d", 2*lsnbddvar+i+1);
    string tmp;
    tmp = buf;
    tmp = "a"+tmp;
    ba.push_back(new BasicBoolForm(2*lsnbddvar+i,tmp) );
  }


  // Now building the protocols. Some vars
  i = 0;
  string tmpstr, tmpstr2;
  string tmpagtname;

  BoolForm bfFalse;
  bfFalse->Zero();
  BoolForm bfTrue;
  bfTrue->One();
  BoolForm bfprot;
  BoolForm tmpact;
  vector < BoolForm > tmpactlist;
  vector < BoolForm > bfprotlist;
  cout << endl << "building boolean formulae for protocols..." << endl;

  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    bfprot = bfFalse;
    tmpagtname = *igs;
    protocol = protlist[i];
    cout << tmpagtname << endl;
    for ( pi = protocol.begin(); pi != protocol.end(); pi++ ) {
      tmpstr = pi->first;
      tmpact = bfFalse;
      for ( si = pi->second.begin(); si != pi->second.end(); si++ ) {
	tmpstr2 = *si;
	BoolForm atempbf = actbf(tmpagtname,tmpstr2);
	//tmpact = tmpact ^ actbdd(tmpagtname,tmpstr2);
	tmpactlist.push_back(atempbf);
      }
      tmpact  = list2xor(tmpactlist);
      bfprotlist.push_back(BoolForm(lsbf(tmpagtname,tmpstr)*tmpact));
      
      tmpactlist.clear();
    }
    bfprot = list2xor(bfprotlist);
    bfp.push_back(BoolForm(bfprot));
    bfprot = bfFalse;
    bfprotlist.clear();
    i++;
  }
  
  cout << "done, " << i << " protocols encoded" << endl;

  cout << endl << "building boolean formulae for transition conditions..." 
       << endl;
  
  BoolForm singlecond, bfevcond, lastcond, dnc, preRT;
  vector < BoolForm > bfevcondlist;

  i = 0;
  int j = 0;
  preRT->One();

  singlecond->Zero();
  bfevcond->Zero();
  lastcond->One();
  dnc->One();

  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    cout << endl<< "Conditions for agent " << i+1 << endl;
    evcond = evcondlist[i];
    tmpagtname = *igs;
    bfevcond = bfFalse;
    lastcond = bfTrue; // The negation of all other conditions;
    int acounter = 1;
    for ( eci = evcond.begin(); eci != evcond.end(); eci++ ) {
      cout << endl<< "Starting condition " << acounter << 
	"for agent " << i+1 << endl;
      tmpstr = eci->first;
      singlecond = BoolForm(lsbfpv(tmpagtname,tmpstr));
      // Returns prime variables.

      singlecond = singlecond * print_pnode_bf(tmpagtname,eci->second);

      bfevcondlist.push_back(BoolForm(singlecond));

      lastcond = lastcond * !(print_pnode_bf(tmpagtname,eci->second));
      acounter++;
    }
  
    // Now I build the condition saying that local states don't change,
    // dnc
    
    dnc = BoolForm(bfTrue);
    int k = 0; // starting variable;
    for ( j = 0; j < i; j++ ) {
      k += nls[j];
    }

    int nvls = nls[i]; // Number of variables for this set of local states;
    
    for ( j = 0; j < nvls; j++ ) {
      (dnc) = (dnc) * ( ( !(*bv[j+k]) + (*bpv[j+k]) ) * 
		    ( (*bv[j+k]) + !(*bpv[j+k]) ) );
    }
    (lastcond) = (lastcond) * (dnc);
    bfevcondlist.push_back(BoolForm(lastcond));
    (bfevcond) = (list2xor(bfevcondlist));
    (preRT) = (preRT) * (bfevcond);
    i++;
  }

  cout << "done, " << i << " transition conditions encoded" << endl;

  ClauseSet cs;

  //  cout << "To cnf-fing.." << endl;
  //preRT = ToCNF(preRT);
  //cout << "Done" << endl;
  
  //  cout << "Is it SAT? " << endl;
  //cout << preRT->IsSAT();
  cout << preRT->ToString();
  cout << endl << "Is it SAT? ..." << endl;
  cout << preRT->IsSAT();

//  showCNF(cs);

}


