void umcEncode(void);
BoolForm actbf(string name, string act);
BoolForm list2xor(vector< BoolForm*> bflist);
BoolForm lsbf(string name, string act);
BoolForm lsbfpv(string name, string lst);
