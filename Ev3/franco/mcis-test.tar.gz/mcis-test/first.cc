/* mcis -- Model Checking for Interpreted Systems
 *     Copyright (C) 2003 Franco Raimondi and Alessio Lomuscio
 *     This program is free software; you can redistribute it and/or modify
 *     it under the terms of the GNU General Public License as published by
 *     the Free Software Foundation; either version 2 of the License, or
 *     (at your option) any later version.
 *     This program is distributed in the hope that it will be useful,
 *     but WITHOUT ANY WARRANTY; without even the implied warranty of
 *     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *     GNU General Public License for more details.
 * 
 *   You should have received a copy of the GNU General Public License
 *   along with this program; if not, write to the Free Software
 *   Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
*/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <setjmp.h>
#include <malloc.h>
#include <math.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

#include <iostream>
#include <cstring>

#if __GNUC__ == 3
#include <sstream>
#else
#include <strstream>
#endif




using std::string;
using std::vector;
using std::map;




extern "C" {
  int yyparse(void);
#include "pnode/pnode2.h"
}

#include "boolform/bf.h"
#include "boolform/umc.hh"
#include "boolform/exceptions.h"

vector<string> agtnames;
vector<string> lstates;
vector<string>::iterator igs,si;
vector< vector<string> > lstatelist;
vector< vector<string> >::iterator lsli;

vector<string> actions;
vector< vector<string> > actionlist;
vector< vector<string> >::iterator ali;

map< string, vector<string> > protocol;
vector < map< string, vector<string> > > protlist;

map< string, pnode_ptr> evcond; /* EVOLUTION FUNCTIONS */
vector < map< string, pnode_ptr> > evcondlist;

map< string, pnode_ptr> evalcond; /* EVALUATION */

vector < pnode_ptr > iscond; /* INITIAL STATES, a single value vector (?) */

map < string, vector < string > > groups; /* For group modalities */

vector < pnode_ptr > formulaelist; /* Formulae to be checked */


// Utility vars:
vector< string > strvect;
//vector < pnode_ptr >::iterator npi;
//map< string, pnode_ptr>::iterator evci;

//map< string, vector<string> >::iterator pi;
//map< string, pnode_ptr>::iterator eci;




vector< int > nls; // number of local states per agent
vector< int > nact; // number of actions per agent


// VARIABLES FOR UMC
vector < BasicBoolForm* > bv, bpv, ba; // Local states, next local states, and actions
vector < BoolForm > bfp; // vector for protocols

float log_2(int x) 
{
  return (log10((float)x)/log10(2.0));
}



void dump_data(void) 
{

  map< string, pnode_ptr>::iterator evci;

  map< string, vector<string> >::iterator pi;
  map< string, pnode_ptr>::iterator eci;
  cout << endl<<endl<<"Dump agents data: "  << endl;

  int i=0;
  
  for( igs = agtnames.begin(); igs != agtnames.end(); igs++) {
    cout << "Name: " << *igs << endl;
    cout << "Local states: ";
    lstates = lstatelist[i];
    for( si = lstates.begin(); si != lstates.end(); si++) {
      cout << *si << " ";
    }  
    cout << endl << "Actions: ";
    actions = actionlist[i];
    for( si = actions.begin(); si != actions.end(); si++) {
      cout << *si << " ";
    } 

    cout << endl << "Protocol: " << endl;
    protocol = protlist[i];
    for ( pi = protocol.begin(); pi != protocol.end(); pi++ ) {
      cout << "    " << pi->first << " : { " ;
      for ( si = pi->second.begin(); si != pi->second.end(); si++ ) {
	cout << *si << " ";
      }
      cout << "}" << endl;
    }
    cout << endl << "Ev. Cond.: " << endl;
    evcond=evcondlist[i];
    for ( eci = evcond.begin(); eci != evcond.end(); eci++ ) {
      cout << "    " << eci->first << " if " ;
      print_pnode(eci->second);
      cout << endl;
    }
    
    cout << endl << "End agent" << i << endl;
    i++;
  }
  cout << endl << "evaluation function: " << endl;
  for ( evci = evalcond.begin(); evci != evalcond.end(); evci++ ) {
    cout << "    " << evci->first << " if " ;
      print_pnode(evci->second);
      cout << endl << " end evaluation function" << endl;
  }
  cout << endl << " initial states:" << endl;
  cout << " ";
  print_pnode(iscond[0]);
  cout << endl << "end Dump" << endl;
}


int main() {

  int whichone = 1;

  vector < pnode_ptr >::iterator npi;

  cout << endl << "starting pnode manager..." << endl;
  pnode_init();
  cout << "done: manager started" << endl;

  cout << endl << "start parsing... " << endl;
  
  yyparse();
  
  cout << "parsing done: " << agtnames.size() << " agents found" << endl;
  
  
  if ( whichone == 0 ) {
    // this is the BDD part
    
    cout << endl << "starting OBDD manager..." << endl;
    
   // bddEncode();
    
    
  } // end of BDD part

  if ( whichone == 1 ) {
    // This is the UMC part
    
    cout << "Starting UMC" << endl;

    umcEncode();

    cout << "Done" << endl;

  }
  
  

  
  

}
