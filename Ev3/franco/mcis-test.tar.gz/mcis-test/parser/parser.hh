// static node_mgr_ *node_mgr; /* Global manager */
// static node_ptr parse_tree;
#include <stdio.h>
#include <string.h>
#include <string>
#include <vector>
#include <map>
#include <algorithm>

using std::string;
using std::vector;
using std::map;



extern int j;
extern vector<string> agtnames;
extern vector<string> lstates;
extern vector< vector<string> > lstatelist; // A vector of lstates

extern vector<string> actions;
extern vector< vector<string> > actionlist;
extern vector<string>::iterator igs;

extern map< string, vector<string> > protocol;
extern vector < map< string, vector<string> > > protlist;

// Utility vars:
extern vector< string > strvect;
