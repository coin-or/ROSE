#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pnode.h"

void pnode_init()
     /* Initialise manager */
{
  pnode_mgr = (pnode_mgr_ *) malloc(sizeof(pnode_mgr_));
  if (pnode_mgr == (pnode_mgr_ *) NULL){
    fprintf(stderr, 
	    "pnode_init: Out of Memory in allocating the pnode manager\n");
    exit(1);
  }
  pnode_mgr->allocated  = 0;
  pnode_mgr->pnodelist   = (pnode_ptr *)0;
  pnode_mgr->nextFree   = (pnode_ptr)0;
  
  pnode_mgr->pnodelist = (pnode_ptr *) malloc(sizeof(pnode_ptr)*(PNODE_HASH_SIZE+1));
  if (pnode_mgr->pnodelist == (pnode_ptr *)NULL) {
    /* Check the possibility to use the rpterr(...) function */
    fprintf(stderr, "pnode_init: Out of Memory in allocating the pnode hash\n");
    exit(1);
  }
  /* Initializes the pnode cache */
  {
      int i;
      for(i = 0; i < PNODE_HASH_SIZE; i++) 
	pnode_mgr->pnodelist[i] = (pnode_ptr)NULL;
      
  }
}

void pnode_close() 
{
  int i;
  //for(i = 0; i < pnode_mgr->allocated; i++) {
  for(i = 0; i < PNODE_HASH_SIZE; i++) {
    free(pnode_mgr->pnodelist[i]);
    pnode_mgr->pnodelist[i] = NULL;
  }
  
  free(pnode_mgr);
  pnode_mgr = NULL;
}


void pnode_info() 
{
  printf("\n %d pnodes allocated \n\n",pnode_mgr->allocated);
}




pnode_ptr pnode_alloc() {
  int i;
  pnode_ptr pnode;

  if (pnode_mgr->allocated < ( PNODE_HASH_SIZE -1)  ) { /* memory is not full */
    pnode_mgr->pnodelist[pnode_mgr->allocated] = (pnode_ptr)malloc(sizeof(PNODE));
    pnode = pnode_mgr->pnodelist[pnode_mgr->allocated];
  }
  
  pnode->id = pnode_mgr->allocated;
  pnode->left = -1;
  pnode->right = -1;
  pnode->value = NULL;
  
  pnode_mgr->allocated++;
  
  return(pnode);
}


pnode_ptr new_pnode(int type, char *value, pnode_ptr left,  pnode_ptr right)
{
  //    extern int yylineno;
    pnode_ptr apnode;

    apnode = pnode_alloc();
    apnode->type           = type;
    //    apnode->lineno         = 0;
    apnode->value = (char *) malloc(sizeof(char)*strlen(value)+1);
    strcpy(apnode->value,value);
    if ( left ) { 
      apnode -> left  = left->id;
    }
    else {
      apnode -> left = -1;
    }
    
    if ( right ) {
      apnode -> right = right->id;
    }
    else {
      apnode -> right = -1;
    }
    
    //printf("Apnode: %s\n value: %s\n",apnode->value,value);
    return apnode;
}


pnode_ptr lookup(short int id) 
{
  int i;
  
  pnode_ptr pnode;

  for ( i = 0; i < pnode_mgr->allocated; i++ ) {
    pnode = pnode_mgr->pnodelist[i];
    if ( pnode->id == id ) return pnode;
  }
  
  return (pnode_ptr) NULL;
}



void print_pnode( pnode_ptr pnode )
{
  if ( pnode->type == LEAF ) {
    printf("%s", pnode->value );
  }
  else {
    if ( pnode->type == 1 ) {
      printf("(");
      print_pnode(lookup(pnode->left));
      printf(")");
      printf(" AND ");
      printf("(");
      print_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 2 ) {
      printf("(");
      print_pnode(lookup(pnode->left));
      printf(")");
      printf(" OR ");
      printf("(");
      print_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 3 ) {
      printf("NOT (");
      print_pnode(lookup(pnode->left));
      printf(")");
    }
  }
}


void print_mgr() 
{
  int i;
  pnode_ptr apnode;
  
  for ( i = 0; i < pnode_mgr->allocated; i++ ) {
    apnode = pnode_mgr->pnodelist[i];
    printf("------\n");
    printf("Type: %d", apnode->type);
  }
}


void print_formula_pnode( pnode_ptr pnode )
{
 if ( pnode->type == LEAF ) {
   printf("%s", pnode->value );
  }
  else {
    if ( pnode->type == 1 ) {
      printf("(");
      print_formula_pnode(lookup(pnode->left));
      //      printf(")");
      printf(" AND ");
      //printf("(");
      print_formula_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 2 ) {
      printf("(");
      print_formula_pnode(lookup(pnode->left));
      //printf(")");
      printf(" OR ");
      //printf("(");
      print_formula_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 3 ) {
      printf("NOT (");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 4 ) {
      printf("(");
      print_formula_pnode(lookup(pnode->left));
      printf(" IMPLIES ");
      print_formula_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 10 ) {
      printf("AG(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 11 ) {
      printf("EG(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 12 ) {
      printf("AX(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 13 ) {
      printf("EX(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 14 ) {
      printf("AF(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 15 ) {
      printf("EF(");
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
    if ( pnode->type == 16 ) {
      printf("A(");
      print_formula_pnode(lookup(pnode->left));
      printf(" U ");
      print_formula_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 17 ) {
      printf("E(");
      print_formula_pnode(lookup(pnode->left));
      printf(" U ");
      print_formula_pnode(lookup(pnode->right));
      printf(")");
    }
    if ( pnode->type == 30 ) {
      printf("K(");
      printf("%s,", pnode->value );
      print_formula_pnode(lookup(pnode->left));
      printf(")");
    }
  }
}

