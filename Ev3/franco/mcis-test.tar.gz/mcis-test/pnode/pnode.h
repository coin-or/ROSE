#include "pnode2.h"

struct pnode_mgr_ {
  long int allocated;            /* Number of pnodes allocated till now */
  pnode_ptr * pnodelist;       /* The pnode hash table */
  pnode_ptr nextFree;         /* List of free pnodes */
};

typedef struct pnode_mgr_ pnode_mgr_;

static pnode_mgr_ *pnode_mgr; /* Global manager */
static pnode_ptr parse_tree;
