#define PNODE_HASH_SIZE 10000
#define MAX_AGENTS 50

#define LEAF 50

/* VARIABLES AND TYPEDEFS */

struct pnode {
  short int id; /* ID from manager */
  short int type; /* 1=AND, 2=OR, 3=NOT, 4=IMPLIES,
		10=AG, 11=EG, 12=AX, 13=EX, 14=AF, 15=EF, 16=AU, 17=EU,
		30=K, 31=GK (everybody knows), 32=GCK (commond knowledge),
		LEAF=a terminal value */
  char * value; /* The value for a leaf or for K operators */
  //short int lineno;
  short int left; /* a pnode to the left */
  short int right; /* a pnode to the right */
};

typedef struct pnode PNODE;


typedef struct pnode * pnode_ptr;

/* FUNCTIONS */
extern void pnode_init(); /*Initialise manager */
extern void pnode_info(); /* Just print some info */
extern void pnode_close(); /* Shut down the manager */
extern pnode_ptr pnode_alloc();
extern pnode_ptr new_pnode(int,char *,pnode_ptr,pnode_ptr);
extern pnode_ptr lookup(short int );
extern void print_pnode( pnode_ptr );
extern void print_mgr();
extern void print_formula_pnode( pnode_ptr pnode );

